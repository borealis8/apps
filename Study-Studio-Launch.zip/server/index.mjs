import http from 'node:http';
import { openBrowser } from './open-browser.mjs';
import { readFile } from 'node:fs/promises';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { tutorInstructions, tutorInput, responseText } from './tutor.js';
export function createTutorServer({ apiKey = process.env.STUDY_TUTOR_API_KEY || process.env.OPENAI_API_KEY, model = process.env.STUDY_TUTOR_MODEL || 'gpt-4.1-mini', fetchProvider = fetch, htmlPath = new URL('../standalone/index.html', import.meta.url) } = {}) {
  const token = randomBytes(32).toString('hex');
  let active = 0, calls = [];
  const server = http.createServer(async (req, res) => {
    const json = (status, payload) => { res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' }); res.end(JSON.stringify(payload)); };
    // Loopback only. Validate Host to prevent DNS rebinding and do not enable CORS.
    const port = server.address()?.port;
    const allowedHosts = [`localhost:${port}`, `127.0.0.1:${port}`];
    if (!allowedHosts.includes(req.headers.host)) return json(403,{error:'Use the local Study Studio address.'});
    const origin = `http://${req.headers.host}`;
    if (req.headers.origin && req.headers.origin !== origin) return json(403,{error:'Open the app from this backend address to use the tutor.'});
    res.setHeader('X-Frame-Options','DENY');
    res.setHeader('Referrer-Policy','no-referrer');
    if (req.url === '/api/tutor/status' && req.method === 'GET') return json(200,{configured:!!apiKey,model});
    if (req.url === '/api/tutor' && req.method === 'POST') {
      const supplied = Buffer.from(req.headers['x-study-token'] || '');
      if (supplied.length !== token.length || !timingSafeEqual(supplied,Buffer.from(token))) return json(403,{error:'Refresh the connected app before using the tutor.'});
      if (!apiKey) return json(503,{error:'The tutor needs a provider key. Set STUDY_TUTOR_API_KEY in the backend environment, then restart it. Never put the key in this HTML app.'});
      if (!req.headers['content-type']?.startsWith('application/json')) return json(415,{error:'Send a JSON request.'});
      let input;
      try {
        const buffers=[]; let size=0;
        for await (const chunk of req) { size+=chunk.length; if (size>10_000_000) { json(413,{error:'This request is too large. Use a smaller source image.'}); req.resume(); return; } buffers.push(chunk); }
        input=tutorInput(JSON.parse(Buffer.concat(buffers).toString()));
      } catch { return json(400,{error:'The tutor request is invalid. Use a text question and a supported source image.'}); }
      calls=calls.filter(t=>t>Date.now()-600_000);
      if (calls.length>=20 || active>=2) return json(429,{error:'Tutor request limit reached. Wait a few minutes before trying again.'});
      calls.push(Date.now()); active++;
      const controller = new AbortController(), timer=setTimeout(()=>controller.abort(),45000);
      const disconnected=()=>{ if(!res.writableEnded) controller.abort(); };
      res.on('close',disconnected);
      try {
        const response=await fetchProvider('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},body:JSON.stringify({model,instructions:tutorInstructions,input,max_output_tokens:1500,store:false}),signal:controller.signal});
        if (!response.ok) return json(response.status===429?429:502,{error:response.status===401?'The provider rejected the backend key. Check its secure configuration.':response.status===429?'The provider is rate limited or out of quota. Check your provider account and try again.':'The AI provider could not complete the request. Check the backend model and provider access, then retry.'});
        const answer=responseText(await response.json());
        if (!answer) return json(502,{error:'The tutor returned no text. Please retry.'});
        if (!res.destroyed) json(200,{message:answer,model});
      } catch {
        if (!res.destroyed) json(504,{error:'The tutor could not respond within the connection time. Check the backend connection and retry.'});
      } finally { clearTimeout(timer); active--; res.off('close',disconnected); }
      return;
    }
    if ((req.url === '/' || req.url === '/index.html') && req.method === 'GET') {
      try {
        const html=await readFile(htmlPath,'utf8');
        res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
        res.end(html.replace('<head>',`<head><meta name="study-tutor-token" content="${token}">`));
      } catch { json(503,{error:'Build the app first: npm run build:standalone'}); }
      return;
    }
    json(404,{error:'Not found.'});
  });
  server.requestTimeout=60000;
  server.headersTimeout=10000;
  return server;
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const port=Number(process.env.STUDY_TUTOR_PORT || 8787);
  if (!Number.isInteger(port) || port < 0 || port > 65535) {
    console.error('STUDY_TUTOR_PORT must be a whole number from 0 to 65535.');
    process.exit(1);
  }
  const server=createTutorServer();
  server.on('error',error=>{
    console.error(error.code==='EADDRINUSE'
      ? 'The Study Studio port is already in use. Close the previous launcher, or change STUDY_TUTOR_PORT in .env and restart.'
      : 'Study Studio could not start its local server. Check the chosen port and try again.');
    process.exitCode=1;
  });
  server.listen(port,'127.0.0.1',()=>{
    const url=`http://localhost:${server.address().port}/`;
    console.log(`Study Studio: ${url}\nKeep this window open while studying.\nAI tutor: ${(process.env.STUDY_TUTOR_API_KEY || process.env.OPENAI_API_KEY) ? 'provider key configured' : 'optional; configure STUDY_TUTOR_API_KEY for AI chat'}`);
    if (process.argv.includes('--open')) {
      openBrowser(url).then(opened=>{
        if(!opened) console.log('Open Google Chrome and enter the Study Studio address printed above.');
      });
    }
  });
}
