import { spawn } from 'node:child_process';
import { access } from 'node:fs/promises';
import path from 'node:path';
function launch(command, args) {
  return new Promise(resolve => {
    const child = spawn(command, args, { stdio: 'ignore', detached: true, windowsHide: true });
    child.once('error', () => resolve(false));
    child.once('spawn', () => { child.unref(); resolve(true); });
  });
}
export async function openBrowser(url) {
  // The CLI supplies a loopback URL built from its actual listening port.
  if (!/^http:\/\/localhost:\d+\/$/.test(url)) return false;
  if (process.platform === 'win32') {
    for (const base of [process.env.PROGRAMFILES, process.env['PROGRAMFILES(X86)'], process.env.LOCALAPPDATA].filter(Boolean)) {
      const exe=path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe');
      try { await access(exe); if(await launch(exe,['--new-window',url])) return true; } catch {}
    }
    return launch('cmd.exe',['/c','start','',url]);
  }
  if (process.platform === 'darwin') {
    try { await access('/Applications/Google Chrome.app'); return launch('open',['-a','Google Chrome',url]); } catch {}
    return launch('open',[url]);
  }
  for (const command of ['google-chrome','google-chrome-stable','chromium','chromium-browser']) {
    if (await launch(command,['--new-window',url])) return true;
  }
  return launch('xdg-open',[url]);
}
