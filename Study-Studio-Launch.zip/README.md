# Study Studio v0.6

A personal study workspace built with React and Vite. Open the standalone HTML in a browser, or run the development app.

## Open or run

Download `Study-Studio.html`, or extract `Study-Studio.zip` and open the HTML file in a full browser. The app, fonts, PDF parser, and worker are bundled; no server or installation is required. To keep existing browser data accessible, replace the older HTML at the same location and use the same browser.

```sh
npm ci
npm run dev
npm test
npm run build
npm run build:standalone
```

The standalone build is `standalone/index.html`. The regular build is `dist`. Node.js 22.19+ or 24.11+ is recommended.

## Multiple files per study set

Create a study set and select several files, or add more in successive selections. Add lecture notes, worksheets, slides, examples, and diagrams together. Each file retains its own extracted text, page/slide sections, and applicable visual previews. A failed file does not remove successfully imported files. Remove individual files before saving.

For an existing set, open its notes and choose **Add or manage source files**. Add or remove sources, then save changes. Additional typed notes remain separate from file content. Flashcards are refreshed from the combined text (up to 50 cards); applied practice can use all source exercises, independently of the flashcard count.

Supported inputs:

| Input | Behavior |
| --- | --- |
| PDF | Extract text and page references; retain visual previews for source problems, figures, diagrams, and pages without text. No fixed page-count limit. |
| DOCX | Extract paragraphs and convert standard Office equations to LaTeX, including fractions, powers, roots, integrals/sums and matrices. Unsupported structures are flagged; attach essential figures separately. |
| PPTX | Extract slide text and standard Office equations, with slide references. Review against the original; attach essential figures separately. |
| TXT / Markdown | Import UTF-8 or UTF-16 text. |
| CSV | Recognize question/prompt/problem, answer, and solution columns; otherwise use as notes. Quoted commas and newlines are supported. |
| JSON | Recognize an array, or a `questions` array, containing question/prompt/problem plus optional answer and solution/steps. Other JSON can be used as notes. |
| HTML | Extract readable text from an inert document; scripts are not executed. |
| PNG / JPEG / WebP | Retain as visual problem sources without pretending to extract OCR text. |

Limits: **100 MB per document**, **25 MB per image**, **250 MB combined source files per import workspace/study set**. Practical capacity also depends on browser memory and storage. Office text expansion is capped at 100 MB. Source-rich backups are not rejected by an arbitrary file-size cap. Older DOC/PPT and encrypted files need conversion or unlocking first.

Image-only study sets are supported. They have no flashcards until text is added, and can still supply visual applied-practice questions. Imported content and visual previews are saved; original Office/PDF binary files are not retained for re-download. Keep your original documents.

## Create practice questions from material

In a study set’s notes, choose **Create practice from this set**, or open **Applied practice → Create from study sets / files**.

1. Select one or several study sets and/or attach practice files directly.
2. Choose **Find practice questions**.
3. Review the extracted exercises, worked examples, source references, illustrations, and any supplied solutions.
4. Select the questions to add. Re-importing the same set skips existing questions.
5. Attempt each question, then reveal its worked reference or edit it as needed.

Extraction recognizes labelled and numbered problems, examples, imperative questions, and solution/answer sections. Cross-page blocks retain their source range. Explicit numerical answers can supply the numerical checker. The app does not solve arbitrary equations or invent missing answers. Automatically extracted boundaries, notation, and units need review, especially with complex PDF layouts.

If no exercises are found, the app creates clearly labelled self-assessed application prompts grounded in the notes. The requested fallback count is configurable (1–100 per file); detected exercises are not capped by that count. Scans and images become editable visual prompts without OCR. Source pages that may contain a supplied answer are initially collapsed during an attempt.

Custom practice questions can also contain multiple attachments in all supported formats. **Use first detected problem from attachments** populates an editable question. For a full question sheet, use the review/import workflow to create separate questions. Separate reference illustrations support images up to 25 MB.

## Practice and study tools

- Formula templates for motion, Ohm’s law, and molar concentration calculate references from chosen values.
- Numerical checks use an explicit tolerance. Written methods and diagrams are self-assessed using worked references and checklists.
- Sketchpad: freehand, arrows, boxes, ellipses, text labels, undo, clear, SVG export, and mouse/touch/stylus input.
- Course/type filters, saved attempts, editable questions, and uploaded reference illustrations.
- Flashcards, scored recall quizzes, searchable study sets, a study planner, exam countdown, and personal profile/goals.

## Saving and backups

Study sets and practice save to IndexedDB, with localStorage fallback. If persistence is blocked, data remains usable in the current session with a warning. Wait for the saved indicator before closing and download a backup if necessary. Clearing browser data deletes saved work.

**Study set backup / Restore sets** covers the study-set library, extracted sources, and previews. **Practice backup / Restore practice** covers practice questions and attempts. They are separate backups. Practice questions retain source excerpts and applicable previews, so they remain understandable without their original study set.

No account, cloud sync, automatic diagram grading, or OCR service is connected. An optional OpenAI tutor uses the separate local backend described below. The interface is English; a language preference can be stored. Notes are processed locally.

## Validation

`npm test` checks card creation, formula calculations, question-bank decoding, cross-page exercise extraction, supplied-solution separation, deterministic IDs, visual-source handling, file formats, size boundaries, and backup validation. Browser checks exercise the offline HTML using PDF/TXT/DOCX/PPTX/image sets, partial failures, generated practice, numeric references, append/remove flows, reload persistence, duplicates, scans, structured question banks, document attachments, and mobile layout. Earlier checks cover drawing, SVG export, backup/restore, storage restrictions, and PDF worker compatibility.


## Readable course notation

The offline bundle includes KaTeX, chemistry notation (`\ce{...}`), and Noto maths/symbol fonts. Use `$...$` or `\(...\)` for inline maths and `$$...$$` or `\[...\]` for display equations. Rendering covers practice questions, source previews, supplied steps, hints, notes, flashcards, quizzes and tutor messages. Your written working has a live notation preview, and the question editor provides examples. Unsupported TeX displays the original expression with a review notice; untrusted HTML and TeX links are not executed.

Unicode Greek letters, operators, superscripts and subscripts remain intact. PDF text extraction cannot reliably recover every equation layout or a damaged/missing font mapping. Pages containing detected maths or unreliable glyph mappings retain lossless source images up to 3200 pixels on the longest side, with a full-size image download. Review warnings and compare the original. Re-import older PDFs for these previews. Standard Office Math structures are converted; unsupported structures are flagged, and images/screenshots remain the fallback. There is no OCR or universal symbol reconstruction.

Numerical answer checks also accept Unicode minus, fractions and scientific notation such as `1.2×10³`, without executing expressions. Units remain separate; symbolic equivalence is not automatically graded.

## AI problem tutor backend

Chat is available beside each applied-practice problem. It requests progressive hints, explanations of notation, or feedback on current working. The AI is instructed to withhold the full solution until asked; this is guidance, not a guaranteed grading result. Conversations save with the practice attempt and appear in practice backups. Send, stop, clear, retry and connection/provider error states are available.

Run locally with Node.js 22.19+ or 24.11+:

```sh
npm run build:standalone
# Copy .env.example to .env and configure STUDY_TUTOR_API_KEY securely.
npm run tutor
```

Open the local address printed by the backend (default port 8787). The server serves the standalone bundle itself. The downloaded tutor ZIP includes this bundle and the backend and needs no npm dependency installation; use its launcher or `node --env-file-if-exists=.env server/index.mjs` directly. The plain HTML still supports all local tools, but AI requires the backend. When moving from file-based HTML to the connected address, export and restore both study-set and practice backups to transfer saved work.

Configuration: `STUDY_TUTOR_API_KEY` (OpenAI key), `STUDY_TUTOR_MODEL` (defaults to `gpt-4.1-mini`), `STUDY_TUTOR_PORT` (defaults to `8787`). `OPENAI_API_KEY` is also accepted by the server for existing local configurations. Keys stay on the backend and are never included in the frontend or logs. Keep `.env` private and untracked. OpenAI API charges apply separately from ChatGPT subscriptions.

On Send, the backend receives the current problem, supplied hint/solution and excerpt, the learner's working/answer, and the latest 20 conversation messages. Selected source pages or saved snippets are sent only when the image option is checked; the tutor uses high image detail. No other library files or sketches are automatically sent. It calls OpenAI's Responses API with `store: false`; provider retention rules still apply. The frontend discloses this sharing before sending.

The server binds only to loopback. Host/origin validation, no CORS, a per-start session token, request limits, two concurrent requests and 20 calls per ten minutes reduce unintended local usage. Provider errors are summarized without exposing response bodies or credentials. Public hosting is outside this local package and requires HTTPS, user authentication and suitable usage controls. Do not expose the local server publicly.

`npm test` additionally covers notation segmentation, safe numerical parsing, damaged glyph preservation, saved-chat validation, missing credentials, provider context, success/error handling, malicious origin/Host rejection and request validation. Browser validation uses a deterministic provider fixture; actual AI responses require a configured key and provider access. A live provider call has not been verified in this environment because no key is configured.


## Laptop launcher and HTML source previews

The laptop launcher package serves the bundled app with `Content-Type: text/html; charset=utf-8` and opens Chrome where available. Use its START-STUDY-STUDIO launcher after extracting the entire ZIP. This avoids opening the download through a text/code preview. Node.js is required; no npm install or API key is required for local study tools. The `--open` flag on `server/index.mjs` opens the browser only after the server is listening. An occupied port produces an actionable message; port 0 reports the actual assigned address.

Raw source displayed in a browser can also indicate `view-source:`, a `.html.txt` filename, or a download preview. A screenshot without the address bar does not distinguish these cases. The launcher is a supported opening method; it does not establish which of these caused the user's original symptom. Keep prior files and backups until saved work has been transferred using both backup/restore flows.


## Repairing illegible source equations (v0.6)

Corrupted PDF text can contain valid Unicode characters from unrelated scripts, even though the PDF artwork itself is correct. The detector now covers mixed-script equation fragments as well as replacement/private-use glyphs. Legitimate single-script multilingual passages and ordinary Greek mathematical notation are preserved. Detection is heuristic; use **Use source images instead of text** when the visual layout is needed even without a warning.

Affected practice questions use a readable heading and original source images as their main statement. PDF formula problems with saved images also default to their source artwork, preserving fractions, superscripts and vector layouts even when a text-level warning is not triggered. Damaged extracted text remains available in a collapsed section and backup. Existing questions reuse saved page images where available; missing images can be repaired with **Attach / replace source pages** or **Fix source symbols**. Choose the original PDF and the specific page numbers/ranges, or upload a PNG/JPEG/WebP screenshot. Only selected repair pages are rendered, so a 150-page PDF does not require rendering all 150 pages for one question. Original PDF binaries are not stored.

The source viewer supports multiple pages, 100–300% zoom, drag-to-crop, percentage-based crop controls, reset to the full page, and PNG snippet downloads. Crop coordinates are stored without deleting the original image. Snippets and source pages persist in practice backups. A full source page may expose a worked answer; crop it to the question when appropriate. Import also offers **Keep every PDF page as an image** for difficult documents, with a storage cost.

When source text is unreliable, numerical checking pauses and the tutor omits damaged source text and its numerical reference. The learner can check images for the tutor to receive; only the selected pages/snippets are sent. **Read source notation** prepares a transcription request without sending it automatically. Provider transcription can be uncertain and must be checked against the source; no live-provider accuracy claim is made. Correct a question/reference in the editor and mark it checked against the source to use its corrected text normally.

A source screenshot or PDF with a readable original appearance is required: the app cannot infer the intended symbols from corrupted text alone. If the PDF artwork is itself damaged, attach a readable screenshot from the original course source.

Validation includes a 150-page PDF with an embedded font and deliberately damaged Unicode mappings, source-image display, legacy questions with/without saved images, multi-page sources, crop/zoom, persisted attempts/crops/chat, targeted PDF repair, screenshot replacement, offline HTML, mobile layout, and a fixture provider verifying consent, omitted damaged text and high-detail snippets.
