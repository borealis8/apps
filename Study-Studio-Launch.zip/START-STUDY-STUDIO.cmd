@echo off
setlocal
cd /d "%~dp0"
if not exist "server\index.mjs" goto incomplete
if not exist "server\tutor.js" goto incomplete
if not exist "server\open-browser.mjs" goto incomplete
if not exist "standalone\index.html" goto incomplete
if not exist "package.json" goto incomplete
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22.19+ or 24.11+ from nodejs.org, then run this launcher again.
  pause
  exit /b 1
)
if not exist .env if exist .env.example copy .env.example .env >nul
echo Starting Study Studio. Keep this window open while studying.
echo No API key is needed for the study tools.
node --env-file-if-exists=.env server/index.mjs --open
pause
exit /b

:incomplete
echo Study Studio has not been fully extracted, or required files are missing.
echo.
echo 1. Close this window and return to your Downloads folder.
echo 2. Right-click Study-Studio-Launch.zip and choose Extract All.
echo 3. Click Extract and open the new, extracted folder.
echo 4. Run START-STUDY-STUDIO.cmd from that folder.
echo.
echo The server and standalone folders must be next to this launcher.
echo Opening the launcher from inside the ZIP will not start the app.
pause
exit /b 1
