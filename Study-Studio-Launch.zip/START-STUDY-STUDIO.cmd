@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22.19+ or 24.11+ from nodejs.org, then run this launcher again.
  pause
  exit /b 1
)
if not exist .env copy .env.example .env >nul
echo Open http://localhost:8787 after the server starts. Keep this window open.
echo For AI chat, enter your provider key in .env and restart this launcher.
node --env-file-if-exists=.env server/index.mjs --open
pause
