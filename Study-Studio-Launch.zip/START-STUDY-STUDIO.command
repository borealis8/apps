#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
for study_required in server/index.mjs server/tutor.js server/open-browser.mjs standalone/index.html package.json; do
  if [ ! -f "$study_required" ]; then
    printf '%s\n' 'Study Studio has not been fully extracted, or required files are missing.' 'Extract the entire ZIP, then run the launcher from the extracted folder.' 'The server and standalone folders must be next to the launcher.'
    read -r -p "Press Enter to close. " || true
    exit 1
  fi
done
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22.19+ or 24.11+ from nodejs.org, then run this launcher again."
  read -r -p "Press Enter to close. "
  exit 1
fi
if [ ! -f .env ] && [ -f .env.example ]; then cp .env.example .env; chmod 600 .env; fi
printf '%s\n' 'Starting Study Studio. Keep this window open while studying.' 'No API key is needed for the study tools.'
node --env-file-if-exists=.env server/index.mjs --open
