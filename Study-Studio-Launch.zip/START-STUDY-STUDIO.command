#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22.19+ or 24.11+ from nodejs.org, then run this launcher again."
  read -r -p "Press Enter to close. "
  exit 1
fi
if [ ! -f .env ]; then cp .env.example .env; chmod 600 .env; fi
printf '%s\n' 'Open http://localhost:8787 after the server starts. Keep this window open.' 'For AI chat, enter your provider key in .env and restart this launcher.'
node --env-file-if-exists=.env server/index.mjs --open
