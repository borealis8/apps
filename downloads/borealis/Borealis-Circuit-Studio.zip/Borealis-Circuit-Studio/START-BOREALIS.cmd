@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js LTS from nodejs.org, then run this launcher again.
  pause
  exit /b 1
)
if not exist "node_modules\pdfjs-dist\package.json" (
  echo Installing the PDF reference reader. Internet access is required on first launch.
  call npm ci --no-audit --no-fund
  if errorlevel 1 (
    echo Installation failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo Open your browser at http://localhost:3000 after the server starts.
echo Live AI requires a private .env file. See AI-SETUP.txt.
node --env-file-if-exists=.env server.mjs
pause
