import {readFile,writeFile} from 'node:fs/promises';
const file=p=>new URL('../'+p,import.meta.url);
const css=(await readFile(file('public/style.css'),'utf8')).replace("@import url('/fonts.css');",'');
const model=(await readFile(file('public/model.js'),'utf8')).replace(/^export /gm,'');
const knowledge=(await readFile(file('public/knowledge.js'),'utf8')).replace(/^export /gm,'');
let app=(await readFile(file('public/app.js'),'utf8')).replace(/^import .*;\n/gm,'');
app=app.replace("fetch('/api/health').then", "(location.protocol==='file:'?Promise.resolve({json:async()=>({assistant:'local-rules'})}):fetch('/api/health')).then");
const html=(await readFile(file('public/index.html'),'utf8')).replace('<link rel="stylesheet" href="/style.css">','<style>'+css+'</style>').replace('<script type="module" src="/app.js"></script>','<script type="module">\n'+model+'\n'+knowledge+'\n'+app+'\n</script>');
await writeFile(file('OPEN-BOREALIS.html'),html);console.log('Built standalone HTML (local assistant + text references; live AI/PDF require launcher).');
