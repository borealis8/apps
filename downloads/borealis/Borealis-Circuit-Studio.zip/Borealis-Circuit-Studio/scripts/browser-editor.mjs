const {chromium}=await import(process.env.BOREALIS_PLAYWRIGHT_MODULE||'playwright-core');import assert from 'node:assert/strict';import fs from 'node:fs/promises';
const browser=await chromium.connectOverCDP('http://127.0.0.1:9222');const ctx=await browser.newContext({viewport:{width:1500,height:1000}});const page=await ctx.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto('http://127.0.0.1:3000');
 const before=await page.locator('[data-component="U2"]').getAttribute('transform');
 const rect=await page.locator('[data-component="U2"] .symbol rect').first().boundingBox();
 await page.mouse.move(rect.x+rect.width/2,rect.y+rect.height/2);await page.mouse.down();await page.mouse.move(rect.x+rect.width/2+60,rect.y+rect.height/2+40,{steps:8});await page.mouse.up();
 const after=await page.locator('[data-component="U2"]').getAttribute('transform');assert.notEqual(before,after,'component drag changes position');
 assert.ok(await page.locator('#property-form').isVisible());
 await page.getByRole('button',{name:'Undo last change',exact:true}).click();assert.equal(await page.locator('[data-component="U2"]').getAttribute('transform'),before);
 await page.getByRole('button',{name:'Connect pins · W',exact:true}).click();
 await page.locator('[data-pin="J1:0"]').click();await page.locator('[data-pin="D1:1"]').click();assert.equal(await page.locator('.net').count(),8);
 await page.getByRole('button',{name:'Undo last change',exact:true}).click();assert.equal(await page.locator('.net').count(),7);
 await page.locator('[data-mode="pcb"]').click();assert.ok(await page.locator('.pcb-board').isVisible());await page.screenshot({path:new URL('../pcb.png',import.meta.url).pathname});
 await page.locator('[data-mode="schematic"]').first().click();
 await page.getByRole('button',{name:'New project',exact:true}).click();await page.locator('#new-name').fill('Integration test project');await page.locator('#name-form').getByRole('button',{name:'Create project',exact:true}).click();assert.equal(await page.locator('[data-component]').count(),0);
 await page.getByRole('button',{name:'Component library',exact:true}).click();await page.locator('[data-add="led"]').click();assert.equal(await page.locator('[data-component]').count(),1);
 await page.getByRole('button',{name:'Delete selected · Delete',exact:true}).click();assert.equal(await page.locator('[data-component]').count(),0);
 await page.getByRole('button',{name:'Workspace settings',exact:true}).click();assert.equal(await page.locator('#assistant-mode option[value="provider"]').evaluate(n=>n.disabled),true);await page.getByRole('button',{name:'Close dialog',exact:true}).click();
 await page.setViewportSize({width:390,height:844});await page.getByRole('button',{name:'Open assistant',exact:true}).click();assert.ok(await page.locator('.right-panel').isVisible());await page.locator('#chat-input').fill('add an LED');await page.getByRole('button',{name:'Send message',exact:true}).click();assert.ok(await page.locator('.apply-part').isVisible());await page.getByRole('button',{name:'Close assistant',exact:true}).click();assert.equal(await page.locator('.right-panel').isVisible(),false);
 await page.setViewportSize({width:1500,height:1000});
 await page.evaluate(()=>localStorage.clear());await page.reload();
 const raw=await page.evaluate(()=>document.querySelector('#board').outerHTML);assert.ok(raw.includes('Editable circuit schematic'));
 await page.getByRole('button',{name:'Export',exact:false}).first().click();let dl=page.waitForEvent('download');await page.locator('[data-export="svg"]').click();const svg=await dl;const saved=await svg.path();assert.ok((await fs.readFile(saved,'utf8')).includes('xmlns="http://www.w3.org/2000/svg"'));
 const p=JSON.parse(await page.evaluate(()=>JSON.stringify({id:'fixture',name:'Imported board',components:[],nets:[]})));await page.locator('#import-file').setInputFiles({name:'project.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(p))});await page.waitForFunction(()=>document.querySelector('#project-title').textContent.includes('Imported board'));assert.ok((await page.locator('#project-title').textContent()).includes('Imported board'));
 await page.locator('#import-file').setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{"bad":true}')});await page.waitForFunction(()=>document.querySelector('#toast').textContent.includes('Import failed'));assert.ok((await page.locator('#toast').textContent()).includes('Import failed'));
 const health=await page.request.get('http://127.0.0.1:3000/api/health');assert.equal((await health.json()).assistant,'local-rules');const chat=await page.request.post('http://127.0.0.1:3000/api/chat',{data:{prompt:'hello',project:p}});assert.equal(chat.status(),503);
 assert.deepEqual(errors,[]);console.log('PASS: drag, property selection, undo drag, pin wiring, undo wiring, PCB, new project, delete, provider status, mobile assistant, SVG export, valid/invalid import, health and unconfigured AI response.');
}finally{await ctx.close();await browser.close();}
