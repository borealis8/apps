import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {aiConfig,chatCompletion} from './ai.mjs';
import {validateProject} from './public/model.js';
const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'public');
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json'};
const server=http.createServer(async(req,res)=>{
 try {
  if(req.url==='/api/health'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true,assistant:aiConfig().key?'provider':'local-rules',version:'1.0.0'}));return;}
  if(req.url==='/api/chat'&&req.method==='POST'){
   if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`&&req.headers.origin!==`https://${req.headers.host}`){res.writeHead(403);res.end('Origin not allowed');return;}
   let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>200000){res.writeHead(413);res.end('Request too large');return;}}
   try{const input=JSON.parse(body);input.project=validateProject(input.project);const reply=await chatCompletion(input);res.setHeader('Content-Type','application/json');res.end(JSON.stringify(reply));}catch(e){res.writeHead(e.status||400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}return;
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end('Method not allowed');return;}
  const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  const target=path.resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
  if(!target.startsWith(root+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
  const data=await readFile(target);res.setHeader('Content-Type',types[path.extname(target)]||'application/octet-stream');
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'");
  res.end(req.method==='HEAD'?undefined:data);
 }catch(e){res.writeHead(e.code==='ENOENT'?404:500);res.end('Request failed');}
});
server.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Borealis Circuit Studio listening on port '+(process.env.PORT||3000)));
