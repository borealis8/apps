import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {aiConfig,chatCompletion} from './ai.mjs';
import {validateProject} from './public/model.js';
const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'public');
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json'};
const server=http.createServer(async(req,res)=>{
 try {
  if(req.url==='/api/health'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true,assistant:aiConfig().key?'provider':'local-rules',model:aiConfig().key?aiConfig().model:null,pdf:true,version:'1.1.0'}));return;}
  if(['/api/chat','/api/references/extract'].includes(req.url)&&req.method==='POST'){
   if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`&&req.headers.origin!==`https://${req.headers.host}`){res.writeHead(403);res.end('Origin not allowed');return;}
   const limit=req.url==='/api/references/extract'?22*1024*1024:4*1024*1024;
   let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>limit){res.writeHead(413);res.end('Request too large');return;}}
   try{const input=JSON.parse(body);let reply;
    if(req.url==='/api/references/extract'){
     if(typeof input.base64!=='string'||input.base64.length>21*1024*1024||!/^[A-Za-z0-9+/]*={0,2}$/.test(input.base64))throw new Error('Invalid PDF upload.');
     const {extractPdf}=await import('./pdf.mjs');reply=await extractPdf(Buffer.from(input.base64,'base64'));
    }else{input.project=validateProject(input.project);reply=await chatCompletion(input);}
    res.setHeader('Content-Type','application/json');res.end(JSON.stringify(reply));
   }catch(e){res.writeHead(e.status||400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}return;
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end('Method not allowed');return;}
  const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  const target=path.resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
  if(!target.startsWith(root+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
  const data=await readFile(target);res.setHeader('Content-Type',types[path.extname(target)]||'application/octet-stream');
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'");
  res.end(req.method==='HEAD'?undefined:data);
 }catch(e){res.writeHead(e.code==='ENOENT'?404:500);res.end('Request failed');}
});
server.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Borealis Circuit Studio listening on port '+(process.env.PORT||3000)));
