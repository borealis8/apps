import {getDocument} from 'pdfjs-dist/legacy/build/pdf.mjs';
import {createRequire} from 'node:module';
import path from 'node:path';
const standardFontDataUrl=path.join(path.dirname(createRequire(import.meta.url).resolve('pdfjs-dist/package.json')),'standard_fonts')+path.sep;
export async function extractPdf(buffer){
 if(buffer.byteLength>15*1024*1024)throw new Error('PDF must be smaller than 15 MB. Import individual chapters for large books.');
 if(Buffer.from(buffer).subarray(0,5).toString()!=='%PDF-')throw new Error('Not a PDF document.');
 const task=getDocument({data:new Uint8Array(buffer),standardFontDataUrl,isEvalSupported:false,disableFontFace:true,useSystemFonts:false});let doc;
 try{doc=await task.promise;if(doc.numPages>500)throw new Error('PDF is limited to 500 pages. Import individual chapters instead.');let characters=0;const pages=[];for(let page=1;page<=doc.numPages;page++){const p=await doc.getPage(page);const content=await p.getTextContent();const text=content.items.map(item=>typeof item.str==='string'?item.str+(item.hasEOL?'\n':' '):'').join('').trim();characters+=text.length;if(characters>1200000)throw new Error('PDF text is too large. Import individual chapters.');pages.push({page,text});p.cleanup();}if(characters<30)throw new Error('No usable text found. This may be a scanned PDF; run OCR or paste a text transcription first.');return {pages,pageCount:doc.numPages,characters};}finally{if(doc)await doc.destroy();else await task.destroy();}
}
