# Flux investigation and Borealis implementation

## Evidence boundary

Public HTTPS reads succeeded for `https://www.flux.ai/` and the public project shell at `https://www.flux.ai/fatenerris/nf-dual-output-buck~cf`. TLS verification remained enabled for these downloads. Authenticated Flux actions were not performed. No private API credentials were used.

Chromium could not load Flux because it did not trust the environment proxy CA. Automatic approval review rejected persistently adding that CA. That trust change was not applied or bypassed. Consequently, there is no rendered live-Flux screenshot, authenticated behavioral capture, or end-to-end Flux AI observation in this investigation. Borealis screenshots show the new application only.

The following shipped JavaScript files were downloaded as inert text through verified HTTPS:

- `index.bdb2c60fc5da9749.js` — app bootstrap and chunk inventory.
- `Editor.c2026b5af9883262.js` — editor chunk.
- `SchematicEditor.43d7f1e31e01e538.js` — schematic chunk.
- `PcbEditor.3827a06fd4451fad.js` — PCB chunk.
- `ControlsPanel.a302f7719dbdd8d5.js` — controls chunk.

They remain in `reference/` for local inspection. Source HTML and complete REA JSON evidence are in `evidence/`. Neither directory is served by the Borealis HTTP server or included in the source download.

## Actual REA analysis

Used `morluto/rea`, installed package `rea-agents@6.7.0`, through its CLI:

```sh
rea analyze-javascript-application /workspace/flux-borealis/reference \
  --source-path flux-editor.js --analysis-timeout-ms 60000 --json
rea analyze-javascript-application /workspace/flux-borealis/reference \
  --source-path SchematicEditor.js --analysis-timeout-ms 60000 --json
```

| Finding | Evidence and confidence | Limits |
| --- | --- | --- |
| Bootstrap is a Webpack/Rspack application with recoverable factory modules | `ev_94cfdab952fe62e3a7b443993e04422fa2878d77026903cb2aaf5fb82d422652`; REA statically parsed 132,821 bytes, visited 34,953 AST nodes, recovered 79 modules, and reported zero parse failures | Static structure does not establish runtime execution |
| Bootstrap declares separate Editor, SchematicEditor, PcbEditor, ControlsPanel and export/history chunks | Direct bootstrap source observation; explicit chunk-name mappings | Names alone do not prove complete features or execution |
| Bootstrap declares React 18.3.1 shared dependencies | Direct bootstrap source observation of module-federation sharing metadata | This describes declared dependencies, not independently observed runtime versions |
| Schematic chunk is parseable as inert JavaScript | `ev_8b1c7355a7d9a1cb04a6398afd059d94044125f93773becf7860d1b7d16dc999`; REA parsed 334,871 bytes, visited 94,807 AST nodes, zero parse failures | REA recovered zero modules for this chunk; semantic reconstruction is incomplete |
| Marketing page describes AI-guided planning, schematic editing, PCB layout, BOM and manufacturing workflows | Direct public HTML observation retained in `evidence/marketing.html` | Product claims were not independently validated |
| Flux's backend AI design and implementation | Unknown | Private server code, prompts, model weights and training data are not exposed by the downloaded shell |

The second pass analyzed one selected file among five inventoried JavaScript files. The other chunks were downloaded and inspected for relevant source strings, but were not comprehensively analyzed with REA. This is a bounded static investigation, not a complete reverse engineering of Flux.

## Independent design choices

Borealis branding derives from the user's `borealis8/apps` repository name. Sage/charcoal styling, editorial typography, local project storage, a curated component palette, the starter sensor circuit, and deterministic assistant behavior are new implementation choices. They are not claims about Flux's private implementation or a pixel-perfect reproduction of its UI.

The application is a working independently written concept-editor prototype. Production ECAD, manufacturing, cloud collaboration, and Flux's private AI are outside its implemented scope. The optional OpenAI-compatible connector is tested against fixtures; no real provider credential was available.

## Validation ledger

- Seven Node domain/AI-adapter tests passed.
- Browser smoke checks passed for initial schematic, component search/insertion, property edits, undo/redo, BOM table, design checks, local chat, reload persistence, project download, and responsive overflow.
- Additional browser checks passed for dragging, pin-to-pin wiring, undo of those operations, PCB preview, creating/deleting components, mobile assistant, SVG export, valid/invalid import handling, and HTTP API behavior. The server returned HTTP 503 for unconfigured live AI as expected. See `validation.log`.
- Original selected repository `/workspace/apps` was left unchanged.
