#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then
  echo 'Install Node.js LTS from nodejs.org, then run this launcher again.'
  exit 1
fi
if [ ! -f node_modules/pdfjs-dist/package.json ]; then
  echo 'Installing the PDF reference reader. Internet access is required on first launch.'
  npm ci --no-audit --no-fund
fi
echo 'Open your browser at http://localhost:3000 after the server starts.'
echo 'Live AI requires a private .env file. See AI-SETUP.txt.'
exec node --env-file-if-exists=.env server.mjs
