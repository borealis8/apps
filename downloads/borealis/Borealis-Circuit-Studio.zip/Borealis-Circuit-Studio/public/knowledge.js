// Local lexical retrieval: send only relevant excerpts to the AI provider.
const stop=new Set('a an and are as at be by can could do does for from how i in is it me my of on or please should that the their them there these they this to use was we what when where which why will with would you your'.split(' '));
export function terms(text){return [...new Set(String(text).toLowerCase().match(/[a-z0-9µΩ]+/g)||[])].filter(t=>t.length>1&&!stop.has(t));}
export function validateSources(sources){
 if(!Array.isArray(sources)||sources.length>12)throw new Error('Keep up to 12 reference documents.');
 let total=0;const ids=new Set();
 for(const s of sources){if(!s||typeof s.id!=='string'||s.id.length>80||ids.has(s.id)||typeof s.title!=='string'||!s.title.trim()||s.title.length>160||!Array.isArray(s.pages)||s.pages.length>500)throw new Error('Invalid reference document.');ids.add(s.id);
 for(const p of s.pages){if(!p||typeof p.text!=='string'||p.text.length>1200000||(p.page!==null&&(!Number.isInteger(p.page)||p.page<1||p.page>500)))throw new Error('Invalid reference page.');total+=p.text.length;}}
 if(total>1200000)throw new Error('The reference library is limited to 1.2 million characters. Import relevant chapters or remove an older source.');return sources;
}
export function retrieveSources(sources,query,limit=4){
 validateSources(sources);const tokens=terms(query);if(!tokens.length)return [];
 const chunks=[];for(const source of sources)for(const page of source.pages){const text=page.text.replace(/\s+/g,' ').trim();for(let start=0;start<text.length;start+=900){const excerpt=text.slice(start,start+1100);if(excerpt.trim())chunks.push({documentId:source.id,title:source.title,page:page.page,excerpt,section:Math.floor(start/900)+1});}}
 const tokenSets=chunks.map(c=>new Set(terms(c.excerpt+' '+c.title)));const df=new Map(tokens.map(t=>[t,tokenSets.filter(set=>set.has(t)).length]));
 const ranked=chunks.map((c,i)=>{const title=terms(c.title);let score=0;for(const t of tokens)if(tokenSets[i].has(t))score+=Math.log(1+(chunks.length+1)/((df.get(t)||0)+1))+(title.includes(t)?1.5:0);return {...c,score,index:i};}).filter(c=>c.score>0).sort((a,b)=>b.score-a.score||a.index-b.index);
 const result=[];for(const c of ranked){if(result.some(r=>r.documentId===c.documentId&&r.page===c.page&&Math.abs(r.section-c.section)<2))continue;result.push({...c,label:'S'+(result.length+1)});if(result.length>=limit)break;}return result;
}
export function offlineReferenceAnswer(sources,prompt,history=[]){const context=history.filter(m=>m.role==='user').slice(-2).map(m=>m.text||m.content||'').join(' ');const matches=retrieveSources(sources,prompt+' '+context,3);if(!matches.length)return null;return {sources:matches,text:'I found these passages in your reference library:\n\n'+matches.map(s=>`[${s.label}] ${s.title}${s.page!==null?` · PDF page ${s.page}`:` · excerpt ${s.section}`}\n“${s.excerpt}”`).join('\n\n')+'\n\nThis is a local excerpt search, not an AI-generated explanation. Enable the AI provider using the launcher for a conversational answer grounded in these passages.'};}
