export const catalog=[
 {kind:'mcu',name:'ESP32-WROOM-32',value:'Wi-Fi + Bluetooth MCU',prefix:'U',price:3.15,category:'Microcontrollers'},
 {kind:'resistor',name:'Resistor',value:'10kΩ',prefix:'R',price:.02,category:'Passives'},
 {kind:'capacitor',name:'Capacitor',value:'100nF',prefix:'C',price:.04,category:'Passives'},
 {kind:'led',name:'LED · green',value:'2.1V · 20mA',prefix:'D',price:.08,category:'Optoelectronics'},
 {kind:'regulator',name:'AMS1117-3.3',value:'3.3V LDO regulator',prefix:'U',price:.24,category:'Power'},
 {kind:'connector',name:'USB-C connector',value:'USB 2.0 · 5V input',prefix:'J',price:.48,category:'Connectors'},
 {kind:'sensor',name:'BME280',value:'Temperature / humidity',prefix:'U',price:2.80,category:'Sensors'},
 {kind:'switch',name:'Tactile switch',value:'Momentary · normally open',prefix:'SW',price:.12,category:'Switches'}
];
export function part(kind,id,x,y,overrides={}){const c=catalog.find(c=>c.kind===kind);return {...c,id,x,y,rotation:0,...overrides};}
export function seedProject(){return {id:'borealis-sensor',name:'Borealis environmental sensor',description:'An ESP32-based connected sensor board',components:[
 part('connector','J1',120,250),part('regulator','U1',340,220),part('capacitor','C1',340,390,{value:'10µF'}),part('mcu','U2',620,300),part('resistor','R1',850,210),part('led','D1',850,390),part('sensor','U3',620,540),part('capacitor','C2',440,540)
],nets:[{id:'n1',from:'J1:1',to:'U1:0',label:'VBUS'},{id:'n2',from:'U1:1',to:'U2:0',label:'+3V3'},{id:'n3',from:'U1:1',to:'C1:0',label:'+3V3'},{id:'n4',from:'U2:1',to:'R1:0',label:'GPIO2'},{id:'n5',from:'R1:1',to:'D1:0',label:'LED'},{id:'n6',from:'U2:1',to:'U3:0',label:'I²C'},{id:'n7',from:'C2:1',to:'U3:0',label:'+3V3'}],updatedAt:Date.now()};}
export function nextId(project,prefix){let i=1;while(project.components.some(c=>c.id===prefix+i))i++;return prefix+i;}
export function pinPosition(c,pin){const h=c.kind==='mcu'?140:c.kind==='sensor'?84:60;const offset=pin===0?-65:65;const a=(c.rotation||0)*Math.PI/180;return {x:c.x+offset*Math.cos(a),y:c.y+offset*Math.sin(a),height:h};}
export function validateProject(p){
 if(!p||typeof p.name!=='string'||!p.name.trim()||p.name.length>100||!Array.isArray(p.components)||p.components.length>500||!Array.isArray(p.nets)||p.nets.length>2000)throw new Error('Invalid project format');
 const ids=new Set();for(const c of p.components){if(!catalog.some(t=>t.kind===c.kind)||typeof c.id!=='string'||!c.id||ids.has(c.id)||!Number.isFinite(c.x)||!Number.isFinite(c.y)||Math.abs(c.x)>100000||Math.abs(c.y)>100000||typeof c.value!=='string'||c.value.length>200||typeof c.name!=='string'||c.name.length>200||!Number.isFinite(c.price)||c.price<0||![0,90,180,270].includes(c.rotation))throw new Error('Invalid component');ids.add(c.id);}
 for(const n of p.nets){if(!n||typeof n.label!=='string'||n.label.length>100||typeof n.id!=='string'||![n.from,n.to].every(v=>typeof v==='string'&&/^[^:]+:[01]$/.test(v)&&ids.has(v.split(':')[0]))||n.from===n.to)throw new Error('Invalid connection');}
 return structuredClone(p);
}
export function checkDesign(p){
 const issues=[];for(const c of p.components){for(const pin of [0,1])if(!p.nets.some(n=>n.from===`${c.id}:${pin}`||n.to===`${c.id}:${pin}`))issues.push({id:c.id,message:`${c.id} · pin ${pin+1} is unconnected`,level:'warning'});}
 for(let i=0;i<p.components.length;i++)for(let j=i+1;j<p.components.length;j++){const a=p.components[i],b=p.components[j];if(Math.hypot(a.x-b.x,a.y-b.y)<75)issues.push({id:a.id,message:`${a.id} and ${b.id} overlap`,level:'error'});}
 return issues;
}
export function bomCsv(p){const cell=v=>'"'+String(v).replaceAll('"','""')+'"';return [['Reference','Part','Value','Unit price (USD)'],...p.components.map(c=>[c.id,c.name,c.value,c.price.toFixed(2)])].map(r=>r.map(cell).join(',')).join('\r\n');}
export function localPlan(prompt,p){const s=prompt.toLowerCase();if(/check|review|issue|rule/.test(s)){const issues=checkDesign(p);return {text:`I checked ${p.components.length} components and ${p.nets.length} connections. ${issues.length?`${issues.length} items need attention:\n${issues.slice(0,5).map(i=>'• '+i.message).join('\n')}`:'No connectivity or overlap issues found.'}\n\nThese are basic connectivity and overlap checks, not electrical simulation or manufacturing validation.`,action:'check'};}
 if(/cost|bom|price/.test(s))return {text:`Your board has ${p.components.length} components. The estimated parts total is $${p.components.reduce((a,c)=>a+c.price,0).toFixed(2)} per board. These are illustrative prices, not live supplier quotes. You can export the complete BOM from the Export menu.`};
 const kind=/led|light/.test(s)?'led':/resistor/.test(s)?'resistor':/capacitor|decoupl/.test(s)?'capacitor':/sensor|humidity|temperature/.test(s)?'sensor':/usb/.test(s)?'connector':/regulator|power/.test(s)?'regulator':null;
 if(kind)return {text:`I can add a ${catalog.find(c=>c.kind===kind).name} to your schematic. It will be unconnected so you can choose the correct nets. Review the datasheet and electrical requirements before wiring.`,kind};
 return {text:`For “${prompt.slice(0,160)}”, start by defining the supply voltage, interfaces, current budget, and board constraints.\n\nFor this ESP32 sensor project:\n1. Use a regulated 3.3V rail.\n2. Place decoupling capacitors near power pins.\n3. Verify sensor I²C pull-ups and addresses.\n4. Review connections before layout.\n\nI’m a local rules-based assistant, not Flux’s AI. Ask me to add an LED, add a sensor, check connections, or estimate the BOM.`};}
